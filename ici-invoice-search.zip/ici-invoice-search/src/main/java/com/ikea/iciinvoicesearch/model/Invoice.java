package com.ikea.iciinvoicesearch.model;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;

import javax.persistence.Id;

import javax.persistence.Table;

import javax.persistence.Column;


@Entity // This tells Hibernate to make a table out of this class
@Table(name="ici_dashboard_v2")

public class Invoice {
	
	
	
	public Invoice() {
		super();
	}

	private Long BD_ID ;
	private String BD_Error_Severity;
	private String CSMId;
	private String STATUS;
	private Long Tota_Net_Amount;
	private String Currency;
	private String ICINo;
	private String Seller;
	private String Buyer;
	private String Consignor;
	private String ICI_Consignee;
	private String Consignee_Country;
	private String Loading_Unit_ID;
	private String CSM_Consignee;
	private String Dispatch_Date;
	private String Estimated_Arrival_Date;
	private String est_duration_arrival_date;
	private Long Actual_Duration;
	private Long CSM_Qty;
	private Long Invoice_Total_QTY;
	private String Dispatch_Event_Received;
	
	
	@Id
	@Column(name = "BD_ID", nullable = false)
	public Long getBD_ID() {
		return BD_ID;
	}
	public void setBD_ID(Long bD_ID) {
		BD_ID = bD_ID;
	}
	
	@Column(name = "BD_ERROR_SEVERITY")
	public String getBD_Error_Severity() {
		return BD_Error_Severity;
	}
	public void setBD_Error_Severity(String bD_Error_Severity) {
		BD_Error_Severity = bD_Error_Severity;
	}
	
	
	
	@Column(name = "CSM_ID")
	public String getCSMId() {
		return CSMId;
	}
	public void setCSMId(String cSMId) {
		CSMId = cSMId;
	}
	@Column(name = "STATUS")
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	
	@Column(name = "TOTAL_NET_AMOUNT")
	public Long getTota_Net_Amount() {
		return Tota_Net_Amount;
	}
	public void setTota_Net_Amount(Long tota_Net_Amount) {
		Tota_Net_Amount = tota_Net_Amount;
	}
	
	@Column(name = "CURRENCY")
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	
	@Column(name = "ICI_NO")
	public String getICINo() {
		return ICINo;
	}
	public void setICINo(String iCINo) {
		ICINo = iCINo;
	}
	
	@Column(name = "SELLER")
	public String getSeller() {
		return Seller;
	}
	
	public void setSeller(String seller) {
		Seller = seller;
	}
	
	@Column(name = "BUYER")
	public String getBuyer() {
		return Buyer;
	}
	public void setBuyer(String buyer) {
		Buyer = buyer;
	}
	
	@Column(name = "CONSIGNOR")
	public String getConsignor() {
		return Consignor;
	}
	public void setConsignor(String consignor) {
		Consignor = consignor;
	}
	
	@Column(name = "ICI_CONSIGNEE")
	public String getICI_Consignee() {
		return ICI_Consignee;
	}
	public void setICI_Consignee(String iCI_Consignee) {
		ICI_Consignee = iCI_Consignee;
	}
	
	@Column(name = "CONSIGNEE_COUNTRY")
	public String getConsignee_Country() {
		return Consignee_Country;
	}
	public void setConsignee_Country(String consignee_Country) {
		Consignee_Country = consignee_Country;
	}
	
	@Column(name = "LOADING_UNIT_ID")
	public String getLoading_Unit_ID() {
		return Loading_Unit_ID;
	}
	public void setLoading_Unit_ID(String loading_Unit_ID) {
		Loading_Unit_ID = loading_Unit_ID;
	}
	
	@Column(name = "CSM_CONSIGNEE")
	public String getCSM_Consignee() {
		return CSM_Consignee;
	}
	public void setCSM_Consignee(String cSM_Consignee) {
		CSM_Consignee = cSM_Consignee;
	}
	
	@Column(name = "DISPATCH_DATE")
	public String getDispatch_Date() {
		return Dispatch_Date;
	}
	public void setDispatch_Date(String dispatch_Date) {
		Dispatch_Date = dispatch_Date;
	}
	
	@Column(name = "ESTIMATED_ARRIVAL_DATE")
	public String getEstimated_Arrival_Date() {
		return Estimated_Arrival_Date;
	}
	public void setEstimated_Arrival_Date(String estimated_Arrival_Date) {
		Estimated_Arrival_Date = estimated_Arrival_Date;
	}
	
	@Column(name = "EST_DURATION_ARRIVAL_DATE")
	public String getEst_duration_arrival_date() {
		return est_duration_arrival_date;
	}
	public void setEst_duration_arrival_date(String est_duration_arrival_date) {
		this.est_duration_arrival_date = est_duration_arrival_date;
	}
	
	@Column(name = "ACTUAL_DURATION")
	public Long getActual_Duration() {
		return Actual_Duration;
	}
	public void setActual_Duration(Long actual_Duration) {
		Actual_Duration = actual_Duration;
	}
	
	@Column(name = "INVOICE_TOTAL_QTY")
	public Long getInvoice_Total_QTY() {
		return Invoice_Total_QTY;
	}
	public void setInvoice_Total_QTY(Long invoice_Total_QTY) {
		Invoice_Total_QTY = invoice_Total_QTY;
	}
	@Column(name = "CSM_QTY")
	public Long getCSM_Qty() {
		return CSM_Qty;
	}
	public void setCSM_Qty(Long cSM_Qty) {
		CSM_Qty = cSM_Qty;
	}
	
	@Column(name = "DISPATCH_EVENT_RECEIVED")
	public String getDispatch_Event_Received() {
		return Dispatch_Event_Received;
	}
	public void setDispatch_Event_Received(String dispatch_Event_Received) {
		Dispatch_Event_Received = dispatch_Event_Received;
	}
	
	@Override
	public String toString() {
		return "Invoice [BD_ID=" + BD_ID + ", BD_Error_Severity=" + BD_Error_Severity + ", CSMId=" + CSMId + ", STATUS="
				+ STATUS + ", Tota_Net_Amount=" + Tota_Net_Amount + ", Currency=" + Currency + ", ICINo=" + ICINo
				+ ", Seller=" + Seller + ", Buyer=" + Buyer + ", Consignor=" + Consignor + ", ICI_Consignee="
				+ ICI_Consignee + ", Consignee_Country=" + Consignee_Country + ", Loading_Unit_ID=" + Loading_Unit_ID
				+ ", CSM_Consignee=" + CSM_Consignee + ", Dispatch_Date=" + Dispatch_Date + ", Estimated_Arrival_Date="
				+ Estimated_Arrival_Date + ", est_duration_arrival_date=" + est_duration_arrival_date
				+ ", Actual_Duration=" + Actual_Duration + ", CSM_Qty=" + CSM_Qty + ", Invoice_Total_QTY="
				+ Invoice_Total_QTY + ", Dispatch_Event_Received=" + Dispatch_Event_Received + "]";
	}
	

}
