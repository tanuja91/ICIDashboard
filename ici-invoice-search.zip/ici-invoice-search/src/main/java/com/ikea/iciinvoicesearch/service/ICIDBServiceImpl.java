package com.ikea.iciinvoicesearch.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.ikea.iciinvoicesearch.model.Invoice;

import com.ikea.iciinvoicesearch.repository.ICIDBRepository;


@Service

public class ICIDBServiceImpl implements ICIDBService {
	
@Autowired 
private ICIDBRepository ICIDb;

@Override
public List<Invoice> findAll() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void save(Invoice user) {
	// TODO Auto-generated method stub
	
}

@Override
public List<Invoice> findByname(String Name) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void delete(long id) {
	// TODO Auto-generated method stub
	
}

@Override
public Optional<Invoice> findById(Long id) {
	// TODO Auto-generated method stub
	return null;
}

	
	

	
	


}
