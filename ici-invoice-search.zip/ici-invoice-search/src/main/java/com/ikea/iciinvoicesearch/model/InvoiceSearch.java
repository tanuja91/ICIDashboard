package com.ikea.iciinvoicesearch.model;


import org.springframework.stereotype.Component;

@Component
public class InvoiceSearch {
	
private String CSMNo;
private String ICINo;
public String getCSMNo() {
	return CSMNo;
}
public void setCSMNo(String cSMNo) {
	CSMNo = cSMNo;
}
public String getICINo() {
	return ICINo;
}
public void setICINo(String iCINo) {
	ICINo = iCINo;
}
public InvoiceSearch() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "InvoiceSearch [CSMNo=" + CSMNo + ", ICINo=" + ICINo + "]";
}
}
