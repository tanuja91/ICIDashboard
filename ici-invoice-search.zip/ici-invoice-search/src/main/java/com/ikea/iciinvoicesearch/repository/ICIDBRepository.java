/**
 * 
 */
package com.ikea.iciinvoicesearch.repository;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ikea.iciinvoicesearch.model.Invoice;


/**
 * @author tapan13
 *
 */


	
	@Repository

	public interface ICIDBRepository extends JpaRepository<Invoice, Long>{
		
		

		List<Invoice> findAll();
		
		List<Invoice> findByICINo(@Param("ICI_NO") String ICINO);
		List<Invoice> findByCSMId(@Param("CSM_ID") String CSMId);

	}

