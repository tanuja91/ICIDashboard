package com.ikea.iciinvoicesearch.service;
import java.util.List;
import java.util.Optional;
import com.ikea.iciinvoicesearch.model.Invoice;
public interface ICIDBService {
	
	    List <Invoice> findAll();

	    void save( Invoice user);

	    List <Invoice> findByname(String Name);
	     
	    void delete(long id);

		Optional<Invoice> findById(Long id);
	}


