package com.ikea.iciinvoicesearch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ikea.iciinvoicesearch.model.Invoice;
import com.ikea.iciinvoicesearch.model.InvoiceSearch;
import com.ikea.iciinvoicesearch.repository.ICIDBRepository;


@Controller
@RequestMapping(path="/ICIDashboard")

public class ICIDashboardController {

	@Autowired 
    private InvoiceSearch invoiceSearch;
	
	@Autowired
	 private ICIDBRepository invoiceService;


@RequestMapping (value="/login",method=RequestMethod.GET)
public String showLoginPage() {
return "login";
}

@RequestMapping (value="/login",method=RequestMethod.POST)
public String showWelcomePage() {;
return "Index";
}

@PostMapping("/Search")
public String searchPage(Model model)
{

model.addAttribute("invoiceSearch" , invoiceSearch);
return "form";
}

@PostMapping("/Submit")
public String searchUser( InvoiceSearch invoiceSearch, ModelMap modelMap)
{
System.out.println("Reached to Post method");
String CSMNo= invoiceSearch.getCSMNo();


List<Invoice> invoice=invoiceService.findByCSMId(CSMNo);
System.out.println(invoice);
modelMap.addAttribute("list", invoice );

return "invoiceDetail";	

}

@PostMapping("/Redirect")
public String redirect()
{
System.out.println("in redirect method");
return	"Index";
}

}
